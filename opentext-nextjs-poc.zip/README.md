# OpenText WebCMS PoC
1. Upload this code to GitHub.
2. Connect the repo to Vercel.
3. Deploy (no extra env vars needed for basic functionality).
